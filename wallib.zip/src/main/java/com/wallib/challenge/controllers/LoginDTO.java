package com.wallib.challenge.controllers;

import lombok.Data;

@Data
public class LoginDTO {
    private String username;
    private String password;
}
