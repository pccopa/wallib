package com.wallib.challenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WallibApplication {

	public static void main(String[] args) {
		SpringApplication.run(WallibApplication.class, args);
	}

}
