package com.wallib.challenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WallibApplicationTests {

	@Test
	void contextLoads() {
	}

}
